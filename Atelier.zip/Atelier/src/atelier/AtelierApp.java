package atelier;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;

public class AtelierApp {

	private JFrame frmEshop;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtelierApp window = new AtelierApp();
					window.frmEshop.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AtelierApp() {
		ConOra.init();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEshop = new JFrame();
		frmEshop.setResizable(false);
		frmEshop.setTitle("Mon eStore");
		frmEshop.setBounds(100, 100, 580, 400);
		frmEshop.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEshop.getContentPane().setLayout(null);
		
		JButton escButton = new JButton("Esc");
		escButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		escButton.setBounds(442, 316, 98, 34);
		frmEshop.getContentPane().add(escButton);
		
		JButton registerButton = new JButton("Enregistrer");
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ClientRegisterFrame frame = new ClientRegisterFrame();
					frame.setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		registerButton.setBounds(79, 240, 150, 50);
		frmEshop.getContentPane().add(registerButton);
		
		JButton connectButton = new JButton("Connecter");
		connectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ClientConnectFrame frame = new ClientConnectFrame();
					frame.setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		connectButton.setBounds(79, 162, 150, 45);
		frmEshop.getContentPane().add(connectButton);
		
		JButton adminButton = new JButton("Administrateur");
		adminButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AdminConnectFrame frame = new AdminConnectFrame();
					frame.setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		adminButton.setBounds(323, 184, 150, 50);
		frmEshop.getContentPane().add(adminButton);
		
		JLabel lblNewLabel = new JLabel("Space Client");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(110, 106, 89, 34);
		frmEshop.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		frmEshop.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Space Administrateur");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(327, 105, 142, 37);
		frmEshop.getContentPane().add(lblNewLabel_2);
		
		
	}
}
