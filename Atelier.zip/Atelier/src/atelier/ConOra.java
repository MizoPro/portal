package atelier;

import java.sql.*;

public class ConOra {

	public static final String ROOT     = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String USERNAME = "HAMZA";
	public static final String PASSWORD = "123456789";
	
	public static final String[] CATEGORIES = { "Électroniques", "Jeux", "Vêtements", "Fournitures", "Sports", "Beauté", "Santé", "Enfants" };
	
	private static Connection con;
	
	public static void init() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(ROOT, USERNAME, PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Statement create() throws SQLException {
		return con.createStatement();
	}
	
	public static PreparedStatement prepare(String sql) throws SQLException {
		return con.prepareStatement(sql);
	}
	
	public static int checkClient(String email, String password) throws SQLException {
		PreparedStatement stmt = con.prepareStatement("SELECT IDClient, Email, Mdp FROM Client WHERE Email = ?");

        stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();
        int id = 0;
        String pass = "";
        while (rs.next()) {
        	id = rs.getInt("IDClient");
            pass = rs.getString("Mdp");
        }
        rs.close();
        return pass.equals(password) ? id : -1;
	}
	
	public static boolean checkAdmin(String email, String password) throws SQLException {
		PreparedStatement stmt = con.prepareStatement("SELECT EmailAdmin, MdpAdmin FROM Admin WHERE EmailAdmin = ?");

        stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();
        String pass = "";
        while (rs.next()) {
            pass = rs.getString("MdpAdmin");
        }
        rs.close();
        return pass.equals(password);
	}

	public static void close() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		
}
