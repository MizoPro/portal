package atelier;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class HistoriqueFrame extends JFrame {

	private final String[] columnNames = {"Client", "Produit", "Date d'achat"};
	private DefaultTableModel model = new DefaultTableModel(columnNames, 0);
	
	/**
	 * Create the frame.
	 */
	public HistoriqueFrame() {
		fetch();

		setTitle("Historique");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 636, 433);
		getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Esc");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(479, 343, 98, 37);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Historique des commandes");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(169, 11, 488, 45);
		getContentPane().add(lblNewLabel_2);
		
		/*JPanel panel = new JPanel();
		panel.setBounds(10, 67, 572, 203);
		getContentPane().add(panel);*/
		
		JTable table = new JTable(model);
        /*//table.setPreferredScrollableViewportSize(new Dimension(500, 70));
        //table.setFillsViewportHeight(true);
        
        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
        table.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
        sortKeys.add(new RowSorter.SortKey(4, SortOrder.ASCENDING));
        sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
        sorter.setSortKeys(sortKeys);*/
        
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 88, 610, 235);
        getContentPane().add(scrollPane);
	}
	
	private void fetch() {
		try {
			PreparedStatement stmt = ConOra.prepare("SELECT * FROM Commande");
	        ResultSet rs = stmt.executeQuery();
	        int client, produit;
	        String date;
	        String prenom = "", nom = "", nomproduit = "";
	        while (rs.next()) {
	            client = rs.getInt("IdClient");
	            produit = rs.getInt("IdProduit");
	            date = rs.getString("DateAchat");
	            PreparedStatement stmt1 = ConOra.prepare("SELECT Nom, Prenom FROM Client WHERE IdClient = ?");
	            stmt1.setInt(1, client);
	            ResultSet rs1 = stmt1.executeQuery();
	            while (rs1.next()) {
	            	nom = rs1.getString("Nom");
	            	prenom = rs1.getString("Prenom");
	            }
	            rs1.close();
	            PreparedStatement stmt2 = ConOra.prepare("SELECT NomProduit FROM Produit WHERE IdProduit = ?");
	            stmt2.setInt(1, produit);
	            ResultSet rs2 = stmt2.executeQuery();
	            while (rs2.next()) {
	            	nomproduit = rs2.getString("NomProduit");
	            }
	            rs2.close();
	            model.addRow(new Object[]{nom + " " + prenom, nomproduit, date});
	        }
	        rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
