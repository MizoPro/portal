package atelier;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Font;

public class ClientConnectFrame extends JFrame {
	private JTextField emailField;
	private JTextField mdpField;

	/**
	 * Create the frame.
	 */
	public ClientConnectFrame() {
		setResizable(false);
		setTitle("Connecter");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 577, 371);
		getContentPane().setLayout(null);
		
		JButton escButton = new JButton("Esc");
		escButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		escButton.setBounds(424, 279, 119, 38);
		getContentPane().add(escButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Connecter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email  = emailField.getText();
				String mdp    = mdpField.getText();
				if (email.equals("") || mdp.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(), "Error de saisie", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					int id = ConOra.checkClient(email, mdp);
					if (id != -1) {
						JOptionPane.showMessageDialog(getContentPane(), "Succ�s", "Dialog", JOptionPane.INFORMATION_MESSAGE);
						ClientPanelFrame frame = new ClientPanelFrame(id);
						frame.setVisible(true);
						setVisible(false);
					} else {
						JOptionPane.showMessageDialog(getContentPane(), "Informations d'identification incorrectes!", "Dialog", JOptionPane.ERROR_MESSAGE);
					}
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(226, 279, 119, 38);
		getContentPane().add(btnNewButton);
		
		emailField = new JTextField();
		emailField.setBounds(291, 112, 219, 20);
		getContentPane().add(emailField);
		emailField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setBounds(136, 115, 145, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(136, 168, 145, 14);
		getContentPane().add(lblMotDePasse);
		
		mdpField = new JTextField();
		mdpField.setColumns(10);
		mdpField.setBounds(291, 165, 219, 20);
		getContentPane().add(mdpField);
		
		JLabel lblNewLabel_2 = new JLabel("Connecter comme Client");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(169, 11, 264, 68);
		getContentPane().add(lblNewLabel_2);
	}

}
