package atelier;

import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.sql.Types;
import java.awt.Font;

public class ClientRegisterFrame extends JFrame {
	private JTextField emailField;
	private JTextField mdpField;
	private JTextField nomField;
	private JTextField prenomField;
	private JTextField telField;

	/**
	 * Create the frame.
	 */
	public ClientRegisterFrame() {
		setTitle("Enregistrer");
		setResizable(false);
		setBounds(100, 100, 577, 364);
		getContentPane().setLayout(null);
		
		JButton escButton = new JButton("Esc");
		escButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		escButton.setBounds(426, 276, 105, 32);
		getContentPane().add(escButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Inscription");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email  = emailField.getText();
				String mdp    = mdpField.getText();
				String nom    = nomField.getText();
				String prenom = prenomField.getText();
				String tel    = telField.getText();
				if (email.equals("") || mdp.equals("") || nom.equals("") || prenom.equals("") || tel.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(), "Error de saisie", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					PreparedStatement stmt = ConOra.prepare("INSERT INTO Client VALUES (?,?,?,?,?,?)");
					stmt.setNull(1, Types.INTEGER);
					stmt.setString(2, email);
					stmt.setString(3, mdp);
					stmt.setString(4, nom);
					stmt.setString(5, prenom);
					stmt.setString(6, tel);
					stmt.executeUpdate();
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JOptionPane.showMessageDialog(getContentPane(), "Inscription compl�te!", "Dialog", JOptionPane.INFORMATION_MESSAGE);
				setVisible(false);
			}
		});
		btnNewButton.setBounds(288, 276, 105, 32);
		getContentPane().add(btnNewButton);
		
		emailField = new JTextField();
		emailField.setBounds(288, 96, 213, 20);
		getContentPane().add(emailField);
		emailField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setBounds(113, 99, 150, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(113, 133, 150, 14);
		getContentPane().add(lblMotDePasse);
		
		mdpField = new JTextField();
		mdpField.setColumns(10);
		mdpField.setBounds(288, 130, 213, 20);
		getContentPane().add(mdpField);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setBounds(113, 161, 150, 14);
		getContentPane().add(lblNom);
		
		nomField = new JTextField();
		nomField.setColumns(10);
		nomField.setBounds(288, 158, 213, 20);
		getContentPane().add(nomField);
		
		JLabel lblPrenom = new JLabel("Prenom");
		lblPrenom.setBounds(113, 189, 150, 14);
		getContentPane().add(lblPrenom);
		
		prenomField = new JTextField();
		prenomField.setColumns(10);
		prenomField.setBounds(288, 186, 213, 20);
		getContentPane().add(prenomField);
		
		JLabel lblTelephone = new JLabel("Telephone");
		lblTelephone.setBounds(113, 217, 150, 14);
		getContentPane().add(lblTelephone);
		
		telField = new JTextField();
		telField.setColumns(10);
		telField.setBounds(288, 214, 213, 20);
		getContentPane().add(telField);
		
		JLabel lblNewLabel_2 = new JLabel("Cr\u00E9er un Compte");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(183, 11, 318, 68);
		getContentPane().add(lblNewLabel_2);
	}
}
