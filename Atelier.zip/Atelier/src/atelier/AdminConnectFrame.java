package atelier;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class AdminConnectFrame extends JFrame {

	private JPanel contentPane;
	private JTextField mdpField;
	private JTextField emailField;

	/**
	 * Create the frame.
	 */
	public AdminConnectFrame() {
		setTitle("Administrateur");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 564, 371);
		getContentPane().setLayout(null);
		
		JButton escButton = new JButton("Esc");
		escButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		escButton.setBounds(423, 282, 108, 37);
		getContentPane().add(escButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Connecter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email  = emailField.getText();
				String mdp    = mdpField.getText();
				if (email.equals("") || mdp.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(), "Error de saisie", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					if (ConOra.checkAdmin(email, mdp)) {
						JOptionPane.showMessageDialog(getContentPane(), "Succ�s", "Dialog", JOptionPane.INFORMATION_MESSAGE);
						AdminPanelFrame frame = new AdminPanelFrame(email);
						frame.setVisible(true);
						setVisible(false);
					} else {
						JOptionPane.showMessageDialog(getContentPane(), "Informations d'identification incorrectes!", "Dialog", JOptionPane.ERROR_MESSAGE);
					}
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(226, 279, 119, 38);
		getContentPane().add(btnNewButton);
		
		emailField = new JTextField();
		emailField.setBounds(291, 112, 219, 20);
		getContentPane().add(emailField);
		emailField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setBounds(136, 115, 145, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(136, 168, 145, 14);
		getContentPane().add(lblMotDePasse);
		
		mdpField = new JTextField();
		mdpField.setColumns(10);
		mdpField.setBounds(291, 165, 219, 20);
		getContentPane().add(mdpField);
		
		JLabel lblNewLabel_2 = new JLabel("Connecter comme Admin");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(171, 0, 337, 90);
		getContentPane().add(lblNewLabel_2);
	}

}
