package atelier;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class AdminPanelFrame extends JFrame {
	private JTextField nomField;
	private JTextField prixField;
	private JTextField qteField;
	private JTextField idField;
	private JComboBox<String> categoryBox;

	/**
	 * Create the frame.
	 */
	public AdminPanelFrame(String email) {
		setTitle("Panneau d'Administration");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 703, 419);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Administrateur: [ " + email + " ]");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(169, 11, 488, 45);
		getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Esc");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(560, 332, 97, 35);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Ajouter");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = idField.getText();
				String nom = nomField.getText();
				String cat = (String) categoryBox.getSelectedItem();
				String prix = prixField.getText();
				String qte = qteField.getText();
				if (nom.equals("") || cat.equals("") || prix.equals("") || qte.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(), "Error de saisie", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					float prixf = Float.parseFloat(prix);
					int qt = Integer.parseInt(qte);
					if (id.equals("")) {
						PreparedStatement stmt = ConOra.prepare("INSERT INTO PRODUIT VALUES (?,?,?,?,?)");
						stmt.setNull(1, Types.INTEGER);
						stmt.setString(2, nom);
						stmt.setString(3, cat);
						stmt.setFloat(4, prixf);
						stmt.setInt(5, qt);
						stmt.executeUpdate();
					} else {
						PreparedStatement stmt = ConOra.prepare("UPDATE Produit SET NomProduit = ?, category = ?, prix = ?, qte = ? WHERE IdProduit = ?");
						stmt.setString(1, nom);
						stmt.setString(2, cat);
						stmt.setFloat(3, prixf);
						stmt.setInt(4, qt);
						stmt.setInt(5, Integer.parseInt(id));
						stmt.executeUpdate();
					}
					
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					ex.printStackTrace();
					return;
				}
				JOptionPane.showMessageDialog(getContentPane(), "Produit " + id +  " a �t� modifi�!", "Dialog", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_1.setBounds(56, 332, 161, 35);
		getContentPane().add(btnNewButton_1);
		
		nomField = new JTextField();
		nomField.setBounds(276, 123, 207, 20);
		getContentPane().add(nomField);
		nomField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Nom");
		lblNewLabel_3.setBounds(169, 126, 108, 14);
		getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton_1_1 = new JButton("Supprimer");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = idField.getText();
				if (id.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(), "Error de saisie", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					String sql = "DELETE FROM Produit WHERE IDPRODUIT=" + id;
					Statement stmt = ConOra.create();
					stmt.executeUpdate(sql);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JOptionPane.showMessageDialog(getContentPane(), "Produit " + id +  " a �t� supprim�!", "Dialog", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_1_1.setBounds(284, 332, 161, 35);
		getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Category");
		lblNewLabel_3_1.setBounds(169, 167, 108, 14);
		getContentPane().add(lblNewLabel_3_1);
		
		prixField = new JTextField();
		prixField.setColumns(10);
		prixField.setBounds(276, 207, 207, 20);
		getContentPane().add(prixField);
		
		JLabel lblNewLabel_3_2 = new JLabel("Prix");
		lblNewLabel_3_2.setBounds(169, 210, 108, 14);
		getContentPane().add(lblNewLabel_3_2);
		
		qteField = new JTextField();
		qteField.setColumns(10);
		qteField.setBounds(276, 261, 207, 20);
		getContentPane().add(qteField);
		
		JLabel lblNewLabel_3_3 = new JLabel("Qte");
		lblNewLabel_3_3.setBounds(169, 264, 108, 14);
		getContentPane().add(lblNewLabel_3_3);
		
		idField = new JTextField();
		idField.setColumns(10);
		idField.setBounds(276, 77, 207, 20);
		getContentPane().add(idField);
		
		JLabel lblNewLabel_3_4 = new JLabel("IdProduit");
		lblNewLabel_3_4.setBounds(169, 80, 108, 14);
		getContentPane().add(lblNewLabel_3_4);
		
		categoryBox = new JComboBox<String>();//ConOra.CATEGORIES);
		categoryBox.setBounds(276, 167, 207, 20);
		getContentPane().add(categoryBox);
		
		JButton btnNewButton_2 = new JButton("Historique");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HistoriqueFrame frame = new HistoriqueFrame();
				frame.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(536, 157, 135, 45);
		getContentPane().add(btnNewButton_2);
	}
}
