package atelier;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class ProductsFrame extends JFrame {
	
	private final String[] columnNames = {"ID", "Nom", "Category", "Prix", "Qte"};
	private DefaultTableModel model = new DefaultTableModel(columnNames, 0) {

	    @Override
	    public boolean isCellEditable(int row, int column) {
	       //all cells false
	       return false;
	    }
	};
	private int id;

	JTable table;
	
	/**
	 * Create the frame.
	 */
	public ProductsFrame(int id) {
		this.id = id;
		fetch();
		setTitle("Produits");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 460);
		getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Esc");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(556, 377, 99, 33);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Les produits");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(169, 11, 264, 45);
		getContentPane().add(lblNewLabel_2);
		
		table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 88, 654, 235);
		getContentPane().add(scrollPane);
		
		JButton btnNewButton_1 = new JButton("Acheter");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int idProduit = (int) table.getValueAt(table.getSelectedRow(), 0);
					PreparedStatement stmt = ConOra.prepare("UPDATE Produit SET Qte = 0 WHERE IdProduit = ?");
					stmt.setInt(1, idProduit);
					stmt.executeUpdate();
					String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
					stmt = ConOra.prepare("INSERT INTO Commande VALUES (?,?,?)");
					stmt.setInt(1, id);
					stmt.setInt(2, idProduit);
					stmt.setString(3, date);
					stmt.executeUpdate();
					JOptionPane.showMessageDialog(getContentPane(), "Achat avec succes!", "Dialog", JOptionPane.INFORMATION_MESSAGE);
					refresh();
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(10, 334, 314, 64);
		getContentPane().add(btnNewButton_1);
	}
	
	protected void refresh() {
		this.invalidate();
		this.validate();
		this.repaint();
	}

	private void fetch() {
		try {
			PreparedStatement stmt = ConOra.prepare("SELECT * FROM Produit WHERE Qte > 0");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int id  = rs.getInt("IdProduit");
				String nom = rs.getString("NomProduit");
				String cat = rs.getString("Category");
				String prix = rs.getString("Prix");
				String qte = rs.getString("Qte");
				model.addRow(new Object[] {id, nom, cat, prix, qte});
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
