package atelier;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;

public class ClientPanelFrame extends JFrame {

	private String email;
	private String mdp;
	private int id;
	private String nom;
	private String prenom;
	private String tel;
	private JTextField prenomField;
	private JTextField nomField;
	private JTextField telField;

	/**
	 * Create the frame.
	 */
	public ClientPanelFrame(int id) {

		this.id = id;
		fetchInfo();
	
		setTitle("Mon espace");
		setResizable(false);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 685, 415);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Shared\\Projects\\Eclipse\\Atelier\\assets\\Logo_small.png"));
		lblNewLabel_1.setBounds(10, 11, 135, 45);
		getContentPane().add(lblNewLabel_1);
		

		JLabel lblNewLabel_2 = new JLabel("Salut, " + nom + " " + prenom + "!");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(169, 11, 264, 68);
		getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Esc");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(526, 315, 116, 45);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Allez \u00E0 Achat");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProductsFrame frame = new ProductsFrame(id);
				frame.setVisible(true);
			}
		});
		btnNewButton_1.setForeground(Color.BLUE);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(441, 134, 201, 122);
		getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Modifier vos param\u00E8tres, si vous voulez:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(20, 67, 309, 69);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("Prenom");
		lblNewLabel_3.setBounds(20, 150, 84, 14);
		getContentPane().add(lblNewLabel_3);
		
		prenomField = new JTextField();
		prenomField.setBounds(159, 147, 233, 20);
		getContentPane().add(prenomField);
		prenomField.setColumns(10);
		
		nomField = new JTextField();
		nomField.setColumns(10);
		nomField.setBounds(159, 187, 233, 20);
		getContentPane().add(nomField);
		
		JLabel lblNewLabel_3_1 = new JLabel("Nom");
		lblNewLabel_3_1.setBounds(20, 190, 84, 14);
		getContentPane().add(lblNewLabel_3_1);
		
		telField = new JTextField();
		telField.setColumns(10);
		telField.setBounds(159, 225, 233, 20);
		getContentPane().add(telField);
		
		JLabel lblNewLabel_3_2 = new JLabel("Tel");
		lblNewLabel_3_2.setBounds(20, 228, 84, 14);
		getContentPane().add(lblNewLabel_3_2);
		
		JButton btnNewButton_2 = new JButton("Modifier");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nom = nomField.getText();
				String prenom = prenomField.getText();
				String tel = telField.getText();
				if (nom.equals("") || prenom.equals("") || tel.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(), "Error de saisie", "Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					PreparedStatement stmt = ConOra.prepare("UPDATE Client SET Nom = ?, Prenom = ?, Tel = ? WHERE IdClient = ?");
					stmt.setString(1, nom);
					stmt.setString(2, prenom);
					stmt.setString(3, tel);
					stmt.setInt(4, id);
					stmt.executeUpdate();
					JOptionPane.showMessageDialog(getContentPane(), "Client " + id +  " a �t� modifi�!", "Dialog", JOptionPane.INFORMATION_MESSAGE);
					setVisible(false);
					ClientPanelFrame frame = new ClientPanelFrame(id);
					frame.setVisible(true);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(getContentPane(), "Error SQL", "Dialog", JOptionPane.ERROR_MESSAGE);
					ex.printStackTrace();
					return;
				}
			}
		});
		btnNewButton_2.setBounds(115, 287, 126, 45);
		getContentPane().add(btnNewButton_2);
	}
	
	private void fetchInfo() {
		try {
			PreparedStatement stmt = ConOra.prepare("SELECT * FROM Client WHERE IdClient = ?");
			stmt.setInt(1, id);
	        ResultSet rs = stmt.executeQuery();
	        while (rs.next()) {
	        	email   = rs.getString("Email");
	            mdp     = rs.getString("Mdp");
	            nom     = rs.getString("Nom");
	            prenom  = rs.getString("Prenom");
	            tel     = rs.getString("Tel");
	        }
	        rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}        
	}
}
